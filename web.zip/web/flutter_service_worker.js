'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/AssetManifest.json": "f35859a4f8bcd54147dcb432eb8a3cae",
"assets/assets/icons/app_icon/icon.png": "ad59b79761d78cc05f70e7640c54c996",
"assets/assets/icons/card_icon/AvatarCardIcon.png": "7ada728b43a49fb93591c52b7316eaf0",
"assets/assets/icons/card_icon/cardImgExample.png": "1bdc5ac3e35495fefff345de7ddf2abb",
"assets/assets/icons/card_icon/DateCardIcon.png": "0de961c5bb380299706915754797ceda",
"assets/assets/icons/card_icon/EventTypeCardIcon.png": "3fc93a38759eaa45dea977c379ef6159",
"assets/assets/icons/card_icon/LocationCardIcon.png": "5667c905b86902abc285775a17599068",
"assets/assets/icons/card_icon/RightArrowCardIcon.png": "47cd689e555d4652c6fc1d58579654c6",
"assets/assets/icons/card_icon/SecondaryLocationCardIcon.png": "76f1e541c09d8fa7795fbb16ef899845",
"assets/assets/icons/details_page/ArrowBackDetailsPage.png": "03c94364b0b92cfa80fd78146c16a581",
"assets/assets/icons/details_page/bookedDetailButtonState.png": "747a1c1f2b657bdfb4ce76ef05f3812c",
"assets/assets/icons/details_page/inProgressDetailButtonState.png": "ed94923ec00aa3654ff3e42f20bef048",
"assets/assets/icons/details_page/participateDetailButtonState.png": "2f920b59f6216c0d90ef530df6bd1d60",
"assets/assets/icons/details_page/scanShareDetailButtonState.png": "9aa88ebabfc6287f6d5bcef16b938153",
"assets/assets/icons/events_page/DoneEventCardStateIcon.png": "0d99726783d6167194fc62abb49225ed",
"assets/assets/icons/events_page/InProgressEventCardStateIcon.png": "044cf5263bd261a026874e26f6cbbdb9",
"assets/assets/icons/events_page/LockedEventCardStateIcon.png": "0a1d12a9826c7534c80f0bfc3e790de1",
"assets/assets/icons/events_page/WaitPaymentEventCardStateIcon.png": "454fbeb3ab128bc10117c13dec507f6a",
"assets/assets/icons/map/MapCloseIcon.png": "a4d93730c2472215b0395d1d0d498536",
"assets/assets/icons/nav_bar_icons/FeedTabIcon.png": "f627a0b8aa1432b2d83df0c2d8f64e21",
"assets/assets/icons/nav_bar_icons/MyTourTabIcon.png": "078900ad12f1cbcb47130e7e65cc92df",
"assets/assets/icons/nav_bar_icons/ProfileTabIcon.png": "a93708d2dc79efb34393bb432d5ea255",
"assets/assets/icons/profile_page/ProfilePageDoneMarkIcon.png": "bf1721272c9b763c358167c57a50d69c",
"assets/assets/icons/profile_page/ProfilePageLeaveIcon.png": "07a6896c79c5856dc637d8f74a42c86e",
"assets/assets/icons/profile_page/ProfilePagePencileIcon.png": "a873f8d1b473c041da0ef5b938f87ab9",
"assets/assets/images/AuthGoogleImg.png": "482cf8ed4a765cd9e551134dcf82459a",
"assets/assets/images/AuthVkImg.png": "eed22747646a8a404bb71731a6cade7c",
"assets/assets/images/background.png": "c5bca380cf59277c68b610f1aaa11473",
"assets/assets/images/logo.png": "0d89a0d41291ff61ac8a736df1a646d9",
"assets/assets/images/logoDesktopClient.png": "0311326a90c26bbb3e8b2f7ad0ecdc18",
"assets/assets/images/logoSplash.png": "f778b98874051f44ef7e929fc041ffa4",
"assets/assets/images/map/MapExample.png": "f30aed0ab276d0f0007421da91fc082d",
"assets/assets/images/map/MapExampleHightRes.png": "723e515ff777f6702c08ff8a8e990c3c",
"assets/assets/images/profile_page/profilePageAvatarImage.png": "46e365a47a84a48d7fb46145ea4c50db",
"assets/FontManifest.json": "ff1fcc7d2a7160d041ca0c789adb466e",
"assets/fonts/Inter/Inter-Black.ttf": "980c7e8757e741bb49c7c96513924c61",
"assets/fonts/Inter/Inter-Bold.ttf": "275bfea5dc74c33f51916fee80feae67",
"assets/fonts/Inter/Inter-ExtraBold.ttf": "c9709fb8e32755490795ce5bd226c3a0",
"assets/fonts/Inter/Inter-ExtraLight.ttf": "0f3ac0692901f70f1ac32cf079355051",
"assets/fonts/Inter/Inter-Light.ttf": "d55f45d07cfe01e8797bd1566561f718",
"assets/fonts/Inter/Inter-Medium.ttf": "ed533866b5c83114c7dddbcbc2288b19",
"assets/fonts/Inter/Inter-Regular.ttf": "079af0e2936ccb99b391ddc0bbb73dcb",
"assets/fonts/Inter/Inter-SemiBold.ttf": "07a48beb92b401297a76ff9f6aedd0ed",
"assets/fonts/Inter/Inter-Thin.ttf": "2dce622147cace7b467d9929b7708430",
"assets/fonts/MaterialIcons-Regular.otf": "95db9098c58fd6db106f1116bae85a0b",
"assets/NOTICES": "712ee19b0ac9420f857095664815b788",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/shaders/ink_sparkle.frag": "afc133839f2f6d43f88a7c1e1cd456c3",
"canvaskit/canvaskit.js": "2bc454a691c631b07a9307ac4ca47797",
"canvaskit/canvaskit.wasm": "bf50631470eb967688cca13ee181af62",
"canvaskit/profiling/canvaskit.js": "38164e5a72bdad0faa4ce740c9b8e564",
"canvaskit/profiling/canvaskit.wasm": "95a45378b69e77af5ed2bc72b2209b94",
"favicon.png": "c69da4c79fc8756a14045413c6f9d5de",
"flutter.js": "f85e6fb278b0fd20c349186fb46ae36d",
"icons/android-chrome-192x192.png": "c69da4c79fc8756a14045413c6f9d5de",
"icons/android-chrome-512x512.png": "1367656707d69f0d698def6bf46bbd0e",
"icons/apple-touch-icon.png": "ff41a40070d71166c53c26ac8e984437",
"index.html": "f4c8b2d0df6892cad8eda30459786fd3",
"/": "f4c8b2d0df6892cad8eda30459786fd3",
"main.dart.js": "a4e24abe8f0e327cc1903da9c20586c0",
"manifest.json": "3072c761fd94bd15e6de8b9853ee2bf3",
"splash/img/dark-1x.png": "5a8d14635b98f5a9e06494dcf30f1575",
"splash/img/dark-2x.png": "7544877ab285f423c1ae50210ac8479c",
"splash/img/dark-3x.png": "9236c8f4ecd7f439543520b3a44d1a39",
"splash/img/dark-4x.png": "16594e42ed37950f7fd3f734765a62e2",
"splash/img/light-1x.png": "5a8d14635b98f5a9e06494dcf30f1575",
"splash/img/light-2x.png": "7544877ab285f423c1ae50210ac8479c",
"splash/img/light-3x.png": "9236c8f4ecd7f439543520b3a44d1a39",
"splash/img/light-4x.png": "16594e42ed37950f7fd3f734765a62e2",
"splash/splash.js": "d6c41ac4d1fdd6c1bbe210f325a84ad4",
"splash/style.css": "0547575a914b641f91314bc1c5a0eeee",
"version.json": "10c2e6435c96c337b1b981c35acafb20"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "main.dart.js",
"index.html",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
